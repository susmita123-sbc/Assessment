# Case Study Scenarios to discuss

## Scenario 1: Cost Allocation and Tracking
**Situation**: The company needs to track and allocate costs accurately across different Warehouses and Stores. The costs include labor, inventory, transportation, and overhead expenses.

**Task**: Discuss the challenges in accurately tracking and allocating costs in a fulfillment environment. Think about what are important considerations for this, what are previous experiences that you have you could related to this problem and elaborate some questions and considerations

**Questions you may have and considerations:**
### Challenges & Considerations
* **Data Granularity and Silos**: Fulfillment data often resides in disparate systems (WMS, TMS, ERP). Tracking exact labor down to a specific store's order or allocating shared transportation costs across mixed-store shipments creates significant telemetry and aggregation challenges.
* **Shared Overhead Allocation**: Accurately distributing fixed warehouse overhead (rent, utilities) and variable resource utilization requires clear, dynamic drivers (e.g., cubic square-footage used per tenant vs. order volume throughput).
* **System Observability**: Without central tracing and consistent unique keys across events, cost data becomes delayed, resulting in reactive rather than proactive financial tracking.

### Strategic Experience Alignment
In large-scale microservice and enterprise integrations, this is fundamentally an event-driven data aggregation problem. By setting up decoupled integration boundaries—such as using message buses to stream operational events (shipped orders, clock-in logs)—and feeding them into an analytical datastore, you can compute real-time cost states without putting an analytical load on operational databases.

### Key Questions to Clarify Scope
1. **What is the source of truth for financial data?** Are we pulling raw financial ledger items from an external ERP (like SAP), or are we calculating operational approximations within our system?
2. **What is the required frequency for allocation updates?** Do these allocations need to process near-real-time to drive operational dashboard metrics, or are they nightly batch reconciliations?
3. **What are the finalized business allocation rules?** Are transportation costs allocated statically by distance, or dynamically based on consignment weight and volume?

----

## Scenario 2: Cost Optimization Strategies
**Situation**: The company wants to identify and implement cost optimization strategies for its fulfillment operations. The goal is to reduce overall costs without compromising service quality.

**Task**: Discuss potential cost optimization strategies for fulfillment operations and expected outcomes from that. How would you identify, prioritize and implement these strategies?

**Questions you may have and considerations:**
### Strategies & Expected Outcomes
* **Dynamic Capacity Routing**: Routing orders to the warehouse closest to the destination store that has both inventory and lower labor/processing rates. *Outcome: Reduced transit times and optimized localized labor usage.*
* **Inventory Placement Optimization**: Predictive stocking based on historical store demand patterns to minimize inter-warehouse stock transfers. *Outcome: Drastic reduction in internal transportation overhead.*

### Identification, Prioritization, and Implementation (Framework)
1. **Identify via Observability**: Leverage observability dashboards (e.g., Grafana visualization over operational log streams) to spot anomalies, bottlenecks, or spikes in regional warehouse processing costs.
2. **Prioritize via ROI Matrix**: Evaluate opportunities based on a 2x2 matrix weighing **Business Impact** (cost reduction potential) against **Technical Complexity** (effort to implement). High-impact, low-complexity changes (e.g., optimizing container packaging algorithms) are taken on first.
3. **Implement via Hexagonal Port Isolation**: Introduce new optimization policies as decoupled core domain use cases. By isolating the logic behind inbound ports, we can test and iterate on new routing or allocation strategies safely without breaking our existing database adapters or REST endpoints.

### Key Questions to Clarify Scope
1. **What are the hard Service Level Agreements (SLAs) with stores?** We must establish the minimum fulfillment speed thresholds to ensure cost-cutting measures do not degrade delivery performance.
2. **Do we have high-quality historical baseline data?** Can we reliably measure the success of an optimization strategy against historical performance, or do we need to establish telemetry baselines first?

----

## Scenario 3: Integration with Financial Systems
**Situation**: The Cost Control Tool needs to integrate with existing financial systems to ensure accurate and timely cost data. The integration should support real-time data synchronization and reporting.

**Task**: Discuss the importance of integrating the Cost Control Tool with financial systems. What benefits the company would have from that and how would you ensure seamless integration and data synchronization?

**Questions you may have and considerations:**
### Importance & Business Benefits
Integrating operational systems with financial ledgers prevents data fragmentation, guarantees a single version of financial truth, and eliminates manual data entry errors. The business gains real-time visibility into profit margins per node, faster end-of-month financial closing cycles, and the agility to adjust pricing or logistics strategies instantly based on changing cost realities.

### Ensuring Seamless Integration & Data Synchronization
* **Decoupled Integration Architecture**: To achieve robust, non-blocking synchronization, use an asynchronous enterprise service bus (such as Azure Service Bus) or managed messaging components. 
* **Resiliency and Fault Tolerance**: Implement robust integration patterns like the **Transactional Outbox Pattern** to ensure that if a financial system goes offline, operational messages are never lost. Use retry queues (Dead Letter Queues) with exponential backoff to handle transient network errors gracefully.
* **Idempotency**: Ensure all inbound financial integration ports are strictly idempotent. If a network blip causes a warehouse event message to be delivered twice, the system must process it safely without doubling the financial allocation.

### Key Questions to Clarify Scope
1. **What integration protocols do the financial systems support?** Are we interacting with modern REST/JSON web services, or are we streaming data via legacy file transfers (e.g., SFTP with CSV/XML)?
2. **What is the system-of-record behavior during conflicts?** If an operational cost calculation drifts from an official audited invoice ledger entry, which system overrides the other?

----

## Scenario 4: Budgeting and Forecasting
**Situation**: The company needs to develop budgeting and forecasting capabilities for its fulfillment operations. The goal is to predict future costs and allocate resources effectively.

**Task**: Discuss the importance of budgeting and forecasting in fulfillment operations and what would you take into account designing a system to support accurate budgeting and forecasting?

**Questions you may have and considerations:**
### Importance of Budgeting and Forecasting
Accurate forecasting allows management to make proactive capacity planning and capital allocation decisions. It ensures warehouses are neither understaffed during peak seasonal surges (leading to missed SLAs) nor over-leased during low-volume months (leading to wasted capacity spend).

### System Design Considerations for High Accuracy
* **Historical Data Preservation**: The underlying database schemas must support immutable historical capture. We cannot simply overwrite data rows; we must maintain historical versions to feed forecasting models.
* **Separation of Concerns (CQRS)**: Forecasting requires processing heavy analytical queries across vast time ranges. Designing the system with a separation of reads and writes ensures that heavy forecasting queries do not degrade the performance of live, transactional warehouse operations.
* **External Variables Injection**: The system must be designed flexibly to ingest external variables alongside historical baselines—such as planned store openings, macroeconomic inflation adjustments, and labor rate changes.

### Key Questions to Clarify Scope
1. **What is the forecasting horizon and window?** Are we designing the system to support weekly rolling operational forecasts, annual strategic budgeting, or both?
2. **Are there data science or ML tools already in use?** Should this system focus on exposing high-quality data endpoints (REST/analytical views) to an external BI/ML tool, or does the tool need to run predictive calculations natively?

----

## Scenario 5: Cost Control in Warehouse Replacement
**Situation**: The company is planning to replace an existing Warehouse with a new one. The new Warehouse will reuse the Business Unit Code of the old Warehouse. The old Warehouse will be archived, but its cost history must be preserved.

**Task**: Discuss the cost control aspects of replacing a Warehouse. Why is it important to preserve cost history and how this relates to keeping the new Warehouse operation within budget?

**Questions you may have and considerations:**
### Cost Control Aspects & Preservation Value
* **Historical Baseline Continuity**: Preserving the old warehouse's cost history provides an immediate operational benchmark. Management can directly compare the new warehouse's ramp-up efficiency, labor costs, and throughput metrics against the historical data of the old facility.
* **Regulatory & Trend Compliance**: Multi-year cost trends are vital for auditing, tax reporting, and long-term contract negotiations. 
* **Budget Tracking**: If the new warehouse inherits the Business Unit Code, the budgeting system must cleanly distinguish between the *historical cost run-rate* of the old infrastructure and the *capital expenditures/initial operational variances* of the new asset to evaluate whether the new site is operating within its ROI projections.

### Technical & Architectural Execution
From a database design perspective, hard-deleting records is out of the question. We must enforce a **Soft-Delete / Auditing pattern** using fields like `archivedAt` timestamps on our records. Furthermore, because database entity structures (`DbWarehouse`) change over time, the system should map older records to a stable historical structure so changes to the active domain entity don't corrupt or misalign past data.

### Key Questions to Clarify Scope
1. **How do we isolate financial calculations during the crossover period?** Will there be a transition phase where both warehouses are running simultaneously? If so, how do we split costs if they share the same Business Unit Code?
2. **Are past cost structures directly comparable?** Does the new warehouse introduce automated workflows (like robotics) that require redefining our operational cost categories, or will it map 1:1 to the old labor/overhead categories?