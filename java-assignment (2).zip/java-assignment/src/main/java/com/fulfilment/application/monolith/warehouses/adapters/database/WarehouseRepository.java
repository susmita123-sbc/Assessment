package com.fulfilment.application.monolith.warehouses.adapters.database;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class WarehouseRepository implements WarehouseStore, PanacheRepository<DbWarehouse> {

  @Override
  public List<Warehouse> getAll() {
    return this.listAll().stream()
        .map(DbWarehouse::toWarehouse)
        .toList();
  }

  @Override
  public void create(Warehouse warehouse) {
    if (warehouse == null) {
      throw new IllegalArgumentException("Warehouse entity cannot be null");
    }
    
    DbWarehouse dbWarehouse = new DbWarehouse();
    // Map all business domain values to your DB entity properties
    dbWarehouse.businessUnitCode = warehouse.businessUnitCode;
    dbWarehouse.location = warehouse.location;
    dbWarehouse.capacity = warehouse.capacity;
    dbWarehouse.stock = warehouse.stock;
    
    this.persist(dbWarehouse);
  }

  @Override
  public void update(Warehouse warehouse) {
    if (warehouse == null || warehouse.businessUnitCode == null) {
      throw new IllegalArgumentException("Warehouse or Business Unit Code cannot be null for updates");
    }
    
    DbWarehouse existingDbRecord = this.find("businessUnitCode", warehouse.businessUnitCode).firstResult();
    
    if (existingDbRecord != null) {
      // Map the fresh updates onto the attached database record active state
      existingDbRecord.location = warehouse.location;
      existingDbRecord.capacity = warehouse.capacity;
      existingDbRecord.stock = warehouse.stock;
      
      this.persist(existingDbRecord);
    }
  }

  @Override
  public void remove(Warehouse warehouse) {
    if (warehouse == null || warehouse.businessUnitCode == null) {
      return;
    }
    this.delete("businessUnitCode", warehouse.businessUnitCode);
  }

  @Override
  public Warehouse findByBusinessUnitCode(String buCode) {
    if (buCode == null || buCode.isBlank()) {
      return null;
    }
    
    DbWarehouse dbWarehouse = this.find("businessUnitCode", buCode).firstResult();
    
    return dbWarehouse != null ? dbWarehouse.toWarehouse() : null;
  }
}