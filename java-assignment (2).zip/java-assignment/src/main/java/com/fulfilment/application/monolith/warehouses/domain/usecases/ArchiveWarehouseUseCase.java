package com.fulfilment.application.monolith.warehouses.domain.usecases;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.ArchiveWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;

@ApplicationScoped
public class ArchiveWarehouseUseCase implements ArchiveWarehouseOperation {

  private final WarehouseStore warehouseStore;

  public ArchiveWarehouseUseCase(WarehouseStore warehouseStore) {
    this.warehouseStore = warehouseStore;
  }

  @Override
  public void archive(Warehouse warehouse) {
    if (warehouse == null) {
      throw new IllegalArgumentException("Cannot archive a null warehouse unit.");
    }

    // Business Rule Check: Do not allow archiving if there is active stock left in the warehouse
    if (warehouse.stock > 0) {
      throw new WebApplicationException(
          "Cannot archive warehouse unit " + warehouse.businessUnitCode + " because it still has active stock: " + warehouse.stock, 
          400
      );
    }

    // Option A: Soft Delete (Matches the pre-filled template hook)
    // If your Warehouse model has an 'archived' or 'active' property, toggle it here:
    // warehouse.archived = true;
    warehouseStore.update(warehouse);

    /* // Option B: Hard Delete
    // If your assignment constraints require completely removing the entry from the database table:
    // warehouseStore.remove(warehouse);
    */
  }
}