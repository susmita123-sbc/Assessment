package com.fulfilment.application.monolith.warehouses.domain.models;

import java.time.LocalDateTime;

public class Warehouse {

  // unique identifier
  public String businessUnitCode;

  public String location;

  public Integer capacity;

  public Integer stock;

  public LocalDateTime getArchivedAt() {
    return this.archivedAt;
  }

  // FIX: Add the setter method
  public void setArchivedAt(LocalDateTime archivedAt) {
    this.archivedAt = archivedAt;
  }

  public LocalDateTime createdAt;

  public LocalDateTime archivedAt;
}