// /package com.fulfilment.application.monolith.location;

// import com.fulfilment.application.monolith.warehouses.domain.models.Location;
// import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
// import java.util.ArrayList;
// import java.util.List;

// public class LocationGateway implements LocationResolver {

//   private static final List<Location> locations = new ArrayList<>();

//   static {
//     locations.add(new Location("ZWOLLE-001", 1, 40));
//     locations.add(new Location("ZWOLLE-002", 2, 50));
//     locations.add(new Location("AMSTERDAM-001", 5, 100));
//     locations.add(new Location("AMSTERDAM-002", 3, 75));
//     locations.add(new Location("TILBURG-001", 1, 40));
//     locations.add(new Location("HELMOND-001", 1, 45));
//     locations.add(new Location("EINDHOVEN-001", 2, 70));
//     locations.add(new Location("VETSBY-001", 1, 90));
//   }
//  @Override
//   public Location resolveByIdentifier(String identifier) {
//     // This temporary snippet will list all methods in Location during compilation
//     for (java.lang.reflect.Method method : Location.class.getDeclaredMethods()) {
//         System.out.println("METHOD FOUND: " + method.getName());
//     }
    
//     // Hardcoded string to break compilation intentionally so you can read the output above
//     String forceBreak = Location.class.getDeclaredFields()[0].getName().toUpperCase(); 

//     return null;
//   }
// }
package com.fulfilment.application.monolith.location;

import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
import jakarta.enterprise.context.ApplicationScoped; 
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped 
public class LocationGateway implements LocationResolver {

  private static final List<Location> locations = new ArrayList<>();

  static {
    locations.add(new Location("ZWOLLE-001", 1, 40));
    locations.add(new Location("ZWOLLE-002", 2, 50));
    locations.add(new Location("AMSTERDAM-001", 5, 100));
    locations.add(new Location("AMSTERDAM-002", 3, 75));
    locations.add(new Location("TILBURG-001", 1, 40));
    locations.add(new Location("HELMOND-001", 1, 45));
    locations.add(new Location("EINDHOVEN-001", 2, 70));
    locations.add(new Location("VETSBY-001", 1, 90));
  }

  @Override
  public Location resolveByIdentifier(String identifier) {
    // FIX: Completely removed the intentional reflection debug hooks and forceBreak code

    if (identifier == null || identifier.isBlank()) {
        return null;
    }

    // FIX: Implemented functional streaming search over the list to look up the location
    return locations.stream()
            .filter(loc -> identifier.equalsIgnoreCase(loc.getIdentifier())) // Assuming getIdentifier() exists on Location
            .findFirst()
            .orElse(null); // Returns null safely if the warehouse identifier isn't in our system records
  }
}
