package com.fulfilment.application.monolith.warehouses.adapters.restapi;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.CreateWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.ReplaceWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.ArchiveWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.adapters.database.WarehouseRepository;
import com.fulfilment.application.monolith.warehouses.adapters.database.DbWarehouse;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/warehouses")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class WarehouseResourceImpl {

    @Inject
    CreateWarehouseOperation createWarehouseOperation;

    @Inject
    ReplaceWarehouseOperation replaceWarehouseOperation;

    @Inject
    ArchiveWarehouseOperation archiveWarehouseOperation;

    @Inject
    WarehouseRepository warehouseRepository;

    // --- POST: CREATE WAREHOUSE ---
    @POST
    public Response createWarehouse(Warehouse warehouse) {
        if (warehouse.capacity == null || warehouse.capacity <= 0) {
            throw new WebApplicationException("Warehouse capacity must be a positive integer greater than zero.", 400);
        }
        if (warehouse.location == null || warehouse.location.isBlank()) {
            throw new WebApplicationException("A valid location identifier must be provided.", 400);
        }

        createWarehouseOperation.create(warehouse);
        return Response.status(Response.Status.CREATED).entity(warehouse).build();
    }

    // --- PUT: REPLACE WAREHOUSE ---
    @PUT
    @Path("/{id}")
    public Response replaceWarehouse(@PathParam("id") Long id, Warehouse updatedData) {
        if (updatedData.capacity == null || updatedData.capacity <= 0) {
            throw new WebApplicationException("Updated warehouse capacity must be greater than zero.", 400);
        }

        // 1. Fetch the database record
        DbWarehouse dbEntity = warehouseRepository.findById(id);
        
        // FIX: Enforces direct field checking to clear line 56 error
        if (dbEntity == null || dbEntity.archivedAt != null) {
            throw new WebApplicationException("Active warehouse instance not found to replace.", 404);
        }

        // 2. Map the data into a clean Domain Model
        Warehouse currentDomain = new Warehouse();
        currentDomain.capacity = dbEntity.capacity;
        currentDomain.location = dbEntity.location;

        // 3. Apply incoming data modifications onto the domain instance
        currentDomain.capacity = updatedData.capacity;
        currentDomain.location = updatedData.location; // FIX: Clears line 67 error

        // 4. Pass the domain object down to our execution port
        replaceWarehouseOperation.replace(currentDomain);
        
        return Response.ok(currentDomain).build();
    }

    // --- DELETE: ARCHIVE WAREHOUSE ---
    @DELETE
    @Path("/{id}")
    public Response archiveWarehouse(@PathParam("id") Long id) {
        // 1. Fetch the database entity record
        DbWarehouse dbEntity = warehouseRepository.findById(id);
        
        // FIX: Enforces direct field checking to clear line 81 error
        if (dbEntity == null || dbEntity.archivedAt != null) {
            throw new WebApplicationException("Active warehouse instance not found.", 404);
        }

        // 2. Map it to a clean Domain Model instance
        Warehouse domainModel = new Warehouse();
        domainModel.capacity = dbEntity.capacity;
        domainModel.location = dbEntity.location;

        // 3. Hand the domain model off to the archive operation port
        archiveWarehouseOperation.archive(domainModel); 
        
        return Response.noContent().build();
    }
}