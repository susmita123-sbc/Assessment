package com.fulfilment.application.monolith.warehouses.domain.usecases;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.CreateWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;

@ApplicationScoped
public class CreateWarehouseUseCase implements CreateWarehouseOperation {

  private final WarehouseStore warehouseStore;

  public CreateWarehouseUseCase(WarehouseStore warehouseStore) {
    this.warehouseStore = warehouseStore;
  }

  @Override
  public void create(Warehouse warehouse) {
    if (warehouse == null) {
      throw new IllegalArgumentException("Warehouse data cannot be null");
    }

    // Business Rule 1: Validate mandatory identification fields
    if (warehouse.businessUnitCode == null || warehouse.businessUnitCode.isBlank()) {
      throw new WebApplicationException("Warehouse Business Unit Code must be provided.", 422);
    }

    // Business Rule 2: Prevent duplicate creation checks
    Warehouse existingWarehouse = warehouseStore.findByBusinessUnitCode(warehouse.businessUnitCode);
    if (existingWarehouse != null) {
      throw new WebApplicationException(
          "Warehouse unit with code " + warehouse.businessUnitCode + " already exists.", 
          409
      );
    }

    // Business Rule 3: Sanity check on capacities
    if (warehouse.capacity < 0) {
      throw new WebApplicationException("Warehouse total capacity cannot be a negative value.", 400);
    }

    if (warehouse.stock > warehouse.capacity) {
      throw new WebApplicationException("Initial stock volume cannot exceed total warehouse capacity.", 400);
    }

    // If all went well, persist the warehouse via the output port
    warehouseStore.create(warehouse);
  }
}