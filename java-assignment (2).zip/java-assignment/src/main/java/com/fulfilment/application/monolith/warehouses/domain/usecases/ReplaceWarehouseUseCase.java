package com.fulfilment.application.monolith.warehouses.domain.usecases;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.ReplaceWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;

@ApplicationScoped
public class ReplaceWarehouseUseCase implements ReplaceWarehouseOperation {

  private final WarehouseStore warehouseStore;

  public ReplaceWarehouseUseCase(WarehouseStore warehouseStore) {
    this.warehouseStore = warehouseStore;
  }

  @Override
  public void replace(Warehouse newWarehouse) {
    if (newWarehouse == null) {
      throw new IllegalArgumentException("Replacement warehouse data cannot be null");
    }

    if (newWarehouse.businessUnitCode == null || newWarehouse.businessUnitCode.isBlank()) {
      throw new WebApplicationException("Business Unit Code must be provided for replacement.", 422);
    }

    // Business Rule 1: Ensure the warehouse already exists before attempting replacement
    Warehouse existingWarehouse = warehouseStore.findByBusinessUnitCode(newWarehouse.businessUnitCode);
    if (existingWarehouse == null) {
      throw new WebApplicationException(
          "Cannot replace warehouse unit " + newWarehouse.businessUnitCode + " because it does not exist.", 
          404
      );
    }

    // Business Rule 2: Ensure the new capacity configuration isn't less than the incoming stock load
    if (newWarehouse.capacity < 0) {
      throw new WebApplicationException("Warehouse capacity cannot be negative.", 400);
    }
    
    if (newWarehouse.stock > newWarehouse.capacity) {
      throw new WebApplicationException("Updated stock level cannot exceed the new warehouse capacity.", 400);
    }

    // Update the store with the new warehouse definitions
    warehouseStore.update(newWarehouse);
  }
}