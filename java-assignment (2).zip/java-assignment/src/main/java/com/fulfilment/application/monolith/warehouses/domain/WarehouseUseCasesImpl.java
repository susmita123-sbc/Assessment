
package com.fulfilment.application.monolith.warehouses.domain;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
// ... keep the rest of your imports and code exactly the same ...
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.ports.CreateWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.ReplaceWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.ArchiveWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
import com.fulfilment.application.monolith.warehouses.adapters.database.WarehouseRepository;
import com.fulfilment.application.monolith.warehouses.adapters.database.DbWarehouse;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Alternative; // Added
import jakarta.annotation.Priority;          // Added
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.WebApplicationException;
import java.time.LocalDateTime;

@ApplicationScoped
@Alternative
@Priority(1) // FORCE Quarkus to choose this bean over any other existing files
public class WarehouseUseCasesImpl implements CreateWarehouseOperation, ReplaceWarehouseOperation, ArchiveWarehouseOperation {

    @Inject
    WarehouseRepository warehouseRepository;

    @Inject
    LocationResolver locationGateway;

    // --- TASK 3: POST / Create Logic ---
    @Override
    @Transactional
    public void create(Warehouse warehouse) {
        Location activeLocation = locationGateway.resolveByIdentifier(warehouse.location);
        if (activeLocation == null) {
            throw new WebApplicationException("Provided location identifier is invalid or does not exist.", 422);
        }

        DbWarehouse entity = new DbWarehouse();
        entity.capacity = warehouse.capacity;
        entity.location = warehouse.location;
        entity.archivedAt = null;

        warehouseRepository.persist(entity);
    }

    // --- TASK 3: PUT / Replace Logic ---
    @Override
    @Transactional
    public void replace(Warehouse modifiedWarehouse) {
        DbWarehouse existingRecord = warehouseRepository.find("location = ?1 and archivedAt is null", modifiedWarehouse.location).firstResult();
        
        if (existingRecord != null) {
            existingRecord.archivedAt = LocalDateTime.now();
            warehouseRepository.persist(existingRecord);
        }

        DbWarehouse newVersion = new DbWarehouse();
        newVersion.capacity = modifiedWarehouse.capacity;
        newVersion.location = modifiedWarehouse.location;
        newVersion.archivedAt = null;

        warehouseRepository.persist(newVersion);
    }

    // --- TASK 3: DELETE / Archive Logic ---
    @Override
    @Transactional
    public void archive(Warehouse warehouse) {
        DbWarehouse existingRecord = warehouseRepository.find("location = ?1 and archivedAt is null", warehouse.location).firstResult();
        if (existingRecord == null) {
            throw new WebApplicationException("Warehouse database instance not found.", 404);
        }

        existingRecord.archivedAt = LocalDateTime.now();
        warehouseRepository.persist(existingRecord);
    }
}