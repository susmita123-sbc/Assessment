package com.fulfilment.application.monolith.warehouses.adapters.restapi;

import com.fulfilment.application.monolith.warehouses.adapters.database.WarehouseRepository;
import com.warehouse.api.WarehouseResource;
import com.warehouse.api.beans.Warehouse;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.WebApplicationException;
import java.util.List;

@RequestScoped
public class WarehouseResourceImpl implements WarehouseResource {

  @Inject private WarehouseRepository warehouseRepository;

  @Override
  public List<Warehouse> listAllWarehousesUnits() {
    return warehouseRepository.getAll().stream().map(this::toWarehouseResponse).toList();
  }

  @Override
  @Transactional
  public Warehouse createANewWarehouseUnit(@NotNull Warehouse data) {
    if (data.getBusinessUnitCode() == null || data.getBusinessUnitCode().isBlank()) {
      throw new WebApplicationException("Business Unit Code is required", 422);
    }

    // Convert API bean data over to Domain Model object
    var domainWarehouse = new com.fulfilment.application.monolith.warehouses.domain.models.Warehouse();
    domainWarehouse.businessUnitCode = data.getBusinessUnitCode();
    domainWarehouse.location = data.getLocation();
    domainWarehouse.capacity = data.getCapacity() != null ? data.getCapacity() : 0;
    domainWarehouse.stock = data.getStock() != null ? data.getStock() : 0;

    warehouseRepository.create(domainWarehouse);

    return toWarehouseResponse(domainWarehouse);
  }

  @Override
  public Warehouse getAWarehouseUnitByID(String id) {
    var domainWarehouse = warehouseRepository.findByBusinessUnitCode(id);
    if (domainWarehouse == null) {
      throw new WebApplicationException("Warehouse with code " + id + " does not exist.", 404);
    }
    return toWarehouseResponse(domainWarehouse);
  }

  @Override
  @Transactional
  public void archiveAWarehouseUnitByID(String id) {
    var domainWarehouse = warehouseRepository.findByBusinessUnitCode(id);
    if (domainWarehouse == null) {
      throw new WebApplicationException("Warehouse with code " + id + " does not exist.", 404);
    }
    warehouseRepository.remove(domainWarehouse);
  }

  @Override
  @Transactional
  public Warehouse replaceTheCurrentActiveWarehouse(String businessUnitCode, @NotNull Warehouse data) {
    var domainWarehouse = warehouseRepository.findByBusinessUnitCode(businessUnitCode);
    if (domainWarehouse == null) {
      throw new WebApplicationException("Warehouse with code " + businessUnitCode + " does not exist.", 404);
    }

    // Update the values on our found record domain model structure mapping bounds
    domainWarehouse.location = data.getLocation();
    domainWarehouse.capacity = data.getCapacity() != null ? data.getCapacity() : domainWarehouse.capacity;
    domainWarehouse.stock = data.getStock() != null ? data.getStock() : domainWarehouse.stock;

    warehouseRepository.update(domainWarehouse);

    return toWarehouseResponse(domainWarehouse);
  }

  private Warehouse toWarehouseResponse(
      com.fulfilment.application.monolith.warehouses.domain.models.Warehouse warehouse) {
    var response = new Warehouse();
    response.setBusinessUnitCode(warehouse.businessUnitCode);
    response.setLocation(warehouse.location);
    response.setCapacity(warehouse.capacity);
    response.setStock(warehouse.stock);

    return response;
  }
}